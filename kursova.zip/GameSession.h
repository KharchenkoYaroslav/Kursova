#ifndef Gamemode_H
#define Gamemode_H

#include <iostream>
using namespace std;

class GameSession
{
public:
    // Гра поле чудес
    static void initSession(); 
};

#endif