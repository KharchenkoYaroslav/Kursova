#include <iostream> 
#include "GameSession.h"

using namespace std;

int main()
{
    GameSession::initSession();
    return 0;
}
